rootProject.name = "PocketSignalMVP"
include(":app")
